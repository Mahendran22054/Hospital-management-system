package com.ehealthcare.servlets;

import com.ehealthcare.utils.DBConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//@WebServlet("/schedule-appointment")
public class Appointment extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String patientId = request.getParameter("patientId");
        String doctorId = request.getParameter("doctorId");
        String appointmentDate = request.getParameter("appointmentDate");
        String appointmentTime = request.getParameter("appointmentTime");
        String reasonForAppointment = request.getParameter("reasonForAppointment");
        boolean confirmation = "on".equals(request.getParameter("confirmation"));

        try (Connection connection = DBConnection.getConnection()) {
            // Step 1: Check if the doctor already has an appointment at the given date and time
            String checkSql = "SELECT COUNT(*) FROM Appointment WHERE doctorID = ? AND appointmentDate = ? AND appointmentTime = ?";
            try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
                checkStmt.setInt(1, Integer.parseInt(doctorId));
                checkStmt.setString(2, appointmentDate);
                checkStmt.setString(3, appointmentTime);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    // If there's already an appointment, send an error message
                    response.getWriter().write("Error: I regret to inform you that this appointment time is unavailable. Please select an alternative time..");
                    return;
                }
            }

            // Step 2: If no conflict, proceed to insert the new appointment
            String insertSql = "INSERT INTO Appointment (patientID, doctorID, appointmentDate, appointmentTime, reasonForAppointment, confirmation) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement insertStmt = connection.prepareStatement(insertSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                insertStmt.setInt(1, Integer.parseInt(patientId));
                insertStmt.setInt(2, Integer.parseInt(doctorId));
                insertStmt.setString(3, appointmentDate);
                insertStmt.setString(4, appointmentTime);
                insertStmt.setString(5, reasonForAppointment);
                insertStmt.setBoolean(6, confirmation);
                insertStmt.executeUpdate();

                // Retrieve the generated appointment ID
                ResultSet rs = insertStmt.getGeneratedKeys();
                int appointmentId = 0;
                if (rs.next()) {
                    appointmentId = rs.getInt(1);
                }

                // Set attributes for the success page
                request.setAttribute("appointmentId", appointmentId);
                request.setAttribute("patientId", patientId);
                request.setAttribute("doctorId", doctorId);
                request.setAttribute("appointmentDate", appointmentDate);
                request.setAttribute("appointmentTime", appointmentTime);

                // Forward to the success page
                RequestDispatcher dispatcher = request.getRequestDispatcher("AppointmentSuccess.jsp");
                dispatcher.forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Error scheduling appointment: " + e.getMessage());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward to the appointment scheduling form
        RequestDispatcher dispatcher = request.getRequestDispatcher("Schedule-Appointment.jsp");
        dispatcher.forward(request, response);
    }
}			