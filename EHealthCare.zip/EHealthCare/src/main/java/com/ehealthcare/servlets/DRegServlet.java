package com.ehealthcare.servlets;

import com.ehealthcare.utils.DBConnection;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@MultipartConfig(maxFileSize = 16177215) // 16MB Max file size
public class DRegServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get text fields
        String doctorName = request.getParameter("doctorName");
        String specialization = request.getParameter("specialization");
        String contactNumber = request.getParameter("contactNumber");
        String email = request.getParameter("email");
        String yearsOfExperience = request.getParameter("yearsOfExperience");
        String medicalLicenseNumber = request.getParameter("medicalLicenseNumber");
        String qualification = request.getParameter("qualification");

        // Get uploaded file
        Part filePart = request.getPart("photo");
        InputStream photoInputStream = null;
        if (filePart != null && filePart.getSize() > 0) {
            photoInputStream = filePart.getInputStream();
        }

        // Validate input
        if (doctorName == null || doctorName.trim().isEmpty()) {
            response.getWriter().write("Error: Doctor Name is required!");
            return;
        }

        try (Connection connection = DBConnection.getConnection()) {
            String sql = "INSERT INTO Doctor (doctorName, specialization, contactNumber, email, yearsOfExperience, medicalLicenseNumber, qualification, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            
            try (PreparedStatement stmt = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, doctorName);
                stmt.setString(2, specialization);
                stmt.setString(3, contactNumber);
                stmt.setString(4, email);
                stmt.setString(5, yearsOfExperience);
                stmt.setString(6, medicalLicenseNumber);
                stmt.setString(7, qualification);

                if (photoInputStream != null) {
                    stmt.setBinaryStream(8, photoInputStream, (int) filePart.getSize());
                } else {
                    stmt.setNull(8, java.sql.Types.BLOB);
                }

                stmt.executeUpdate();

                ResultSet rs = stmt.getGeneratedKeys();
                int doctorId = 0;
                if (rs.next()) {
                    doctorId = rs.getInt(1);
                }

                request.setAttribute("doctorId", doctorId);
                request.setAttribute("doctorName", doctorName);
                request.setAttribute("specialization", specialization);

                RequestDispatcher dispatcher = request.getRequestDispatcher("DoctorSuccess.jsp");
                dispatcher.forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Error registering doctor: " + e.getMessage());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("Doctor-Registration.jsp");
        dispatcher.forward(request, response);
    }
}
