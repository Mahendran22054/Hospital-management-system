package com.ehealthcare.servlets;

import com.ehealthcare.utils.DBConnection;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/doctor-photo")
public class Feedback extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int doctorId = Integer.parseInt(request.getParameter("doctorId"));

        try (Connection connection = DBConnection.getConnection()) {
            String sql = "SELECT photo FROM Doctor WHERE doctorId = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, doctorId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    byte[] imageData = rs.getBytes("photo");

                    if (imageData != null) {
                        response.setContentType("image/jpeg");
                        OutputStream outputStream = response.getOutputStream();
                        outputStream.write(imageData);
                        outputStream.close();
                    } else {
                        response.sendError(HttpServletResponse.SC_NOT_FOUND); // No image found
                    }
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND); // Doctor not found
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
