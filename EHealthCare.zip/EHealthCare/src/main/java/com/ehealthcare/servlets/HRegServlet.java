package com.ehealthcare.servlets;

import com.ehealthcare.utils.DBConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//@WebServlet("/register-hospital")
public class HRegServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String hospitalName = request.getParameter("hospitalName");
        String hospitalLocation = request.getParameter("hospitalLocation");
        String contactNumber = request.getParameter("contactNumber");
        String email = request.getParameter("email");
        String numberOfBeds = request.getParameter("numberOfBeds");
        String specialities = request.getParameter("specialities");
        String insuranceAccepted = request.getParameter("insuranceAccepted");
        String hospitalType = request.getParameter("hospitalType");
        
        try (Connection connection = DBConnection.getConnection()) {
            String sql = "INSERT INTO Hospital (hospitalName, hospitalLocation, contactNumber, email, numberOfBeds,specialities , insuranceAccepted, hospitalType) VALUES (?, ?, ?,?,?,?,?,?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, hospitalName);
                stmt.setString(2, hospitalLocation);
                stmt.setString(3, contactNumber);
                stmt.setString(4, email);
                stmt.setString(5, numberOfBeds);
                stmt.setString(6, specialities);
                stmt.setString(7, insuranceAccepted);
                stmt.setString(8, hospitalType);
                stmt.executeUpdate();
                response.getWriter().write("Hospital registered successfully!");
                
                ResultSet rs = stmt.getGeneratedKeys(); 
                int hospitalId = 0; 
                if (rs.next()) { hospitalId = rs.getInt(1); } 
                request.setAttribute("hospitalId", hospitalId); request.setAttribute("hospitalName", hospitalName); request.setAttribute("contactNumber", contactNumber);request.setAttribute("hospitalLocation", hospitalLocation); // Forward to the success.jsp page 
                RequestDispatcher dispatcher = request.getRequestDispatcher("HospitalSuccess.jsp");
                dispatcher.forward(request, response); }
            
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Error registering hospital: " + e.getMessage());
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("Hospital-registration.jsp");
        dispatcher.forward(request, response);

    }
}
