package com.ehealthcare.servlets;


import com.ehealthcare.utils.DBConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//@WebServlet("/register-patient")
public class PRegServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String patientName = request.getParameter("patientName");
        String age = request.getParameter("age");
        String gender = request.getParameter("gender");
        String contactNumber = request.getParameter("contactNumber");
        String address = request.getParameter("address");
        String emergencyContact = request.getParameter("emergencyContact");
        String  medicalHistory = request.getParameter("medicalHistory");
        String currentMedication = request.getParameter("currentMedication");
        String insuranceProvider = request.getParameter("insuranceProvider");
        String insurancePolicy = request.getParameter("insurancePolicy");

        try (Connection connection = DBConnection.getConnection()) {
            String sql = "INSERT INTO Patient ( patientName, age,gender, contactNumber, address,emergencyContact, medicalHistory, currentMedication, insuranceProvider, insurancePolicy ) VALUES (?, ?, ?, ?,?,?,?,?,?,?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, patientName);
                stmt.setString(2, age);
                stmt.setString(3, gender);
                stmt.setString(4, contactNumber);
                stmt.setString(5, address);
                stmt.setString(6, emergencyContact);
                stmt.setString(7,  medicalHistory);
                stmt.setString(8, currentMedication);
                stmt.setString(9, insuranceProvider);
                stmt.setString(10, insurancePolicy);
                stmt.executeUpdate();
                response.getWriter().write("Patient registered successfully!");
               
                ResultSet rs = stmt.getGeneratedKeys(); 
                int patientId = 0; 
                if (rs.next()) { patientId = rs.getInt(1); } 
                request.setAttribute("patientId", patientId); request.setAttribute("patientName", patientName); request.setAttribute("contactNumber", contactNumber); // Forward to the success.jsp page 
                RequestDispatcher dispatcher = request.getRequestDispatcher("PatientSuccess.jsp");
                dispatcher.forward(request, response); }
                
            
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Error registering patient: " + e.getMessage());
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("Patient-registration.jsp");
        dispatcher.forward(request, response);

    }
}
