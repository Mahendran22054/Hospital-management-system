package com.ehealthcare.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    // JDBC URL, username, and password
    private static final String URL = "jdbc:mysql://localhost:3306/EHealthCare";
    private static final String USERNAME = "root"; // Replace with your database username
    private static final String PASSWORD = "mahi9600"; // Replace with your database password

    // Connection method
    public static Connection getConnection() throws SQLException {
        Connection connection = null;
        try {
            // Register JDBC driver (not required for newer JDBC versions, but good practice)
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Database connection successful!");
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database connection failed!");
            e.printStackTrace();
            throw e;
        }
        return connection;
    }
}
